# ArduinoCore-AT32F4
## Using this core with the Arduino IDE

To compile for this core with the Arduino IDE, add the following URL to the boards manager.

`https://github.com/igorbig/MYArterYteK/tree/main/ArterYteK/hardware/AT-START-F437/0.0.6`
![image](https://user-images.githubusercontent.com/57818792/180649925-ed366423-5f76-42d5-b801-dd5ed2923825.png)
