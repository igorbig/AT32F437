./AT32_ISP_Console.sh
export LD_LIBRARY_PATH=$(pwd)
./AT32_ISP_Console -dfu -p --dfap --depp
