#!/bin/sh


FILENAME="$PWD/libFiles.so"
if [ ! -e "$FILENAME" ]; then
ln -s $PWD/libFiles.so.1.0.0 $PWD/libFiles.so
fi

FILENAME="$PWD/libFiles.so.1"
if [ ! -e "$FILENAME" ]; then
ln -s $PWD/libFiles.so.1.0.0 $PWD/libFiles.so.1
fi

FILENAME="$PWD/libATBLLIB.so"
if [ ! -e "$FILENAME" ]; then
ln -s $PWD/libATBLLIB.so.1.0.0 $PWD/libATBLLIB.so
fi

FILENAME="$PWD/libATBLLIB.so.1"
if [ ! -e "$FILENAME" ]; then
ln -s $PWD/libATBLLIB.so.1.0.0 $PWD/libATBLLIB.so.1
fi

FILENAME="$PWD/libATUARTBLLIB.so"
if [ ! -e "$FILENAME" ]; then
ln -s $PWD/libATUARTBLLIB.so.1.0.0 $PWD/libATUARTBLLIB.so
fi

FILENAME="$PWD/libATUARTBLLIB.so.1"
if [ ! -e "$FILENAME" ]; then
ln -s $PWD/libATUARTBLLIB.so.1.0.0 $PWD/libATUARTBLLIB.so.1
fi

FILENAME="$PWD/libATI2CBLLIB.so"
if [ ! -e "$FILENAME" ]; then
ln -s $PWD/libATI2CBLLIB.so.1.0.0 $PWD/libATI2CBLLIB.so
fi

FILENAME="$PWD/libATI2CBLLIB.so.1"
if [ ! -e "$FILENAME" ]; then
ln -s $PWD/libATI2CBLLIB.so.1.0.0 $PWD/libATI2CBLLIB.so.1
fi

FILENAME="$PWD/libATDFULIB.so"
if [ ! -e "$FILENAME" ]; then
ln -s $PWD/libATDFULIB.so.1.0.0 $PWD/libATDFULIB.so
fi

FILENAME="$PWD/libATDFULIB.so.1"
if [ ! -e "$FILENAME" ]; then
ln -s $PWD/libATDFULIB.so.1.0.0 $PWD/libATDFULIB.so.1
fi

FILENAME="$PWD/libQt5Core.so.5"
if [ ! -e "$FILENAME" ]; then
  ln -s $PWD/libQt5Core.so.5.9.0 $PWD/libQt5Core.so.5
fi
