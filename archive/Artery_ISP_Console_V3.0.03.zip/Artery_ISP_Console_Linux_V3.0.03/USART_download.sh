./AT32_ISP_Console.sh
export LD_LIBRARY_PATH=$(pwd)
./AT32_ISP_Console -com --pn ttyACM0 --br 115200 --db 8 --pr EVEN --to 5 -p --dfap --depp -e --all -d --a 08000000 --fn /home/artery/test_binhex/test_64k.bin --v --o 
